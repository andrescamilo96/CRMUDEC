<!DOCTYPE html>
<html>
<head>
	<title>Mensaje Recibido</title>
</head>
<body>
<H1>CRM UDEC FACATATIVA</H1>
<p>
	Hola Sr(a): {{ $msg->usuario->name }}<br>

	Tienes una nueva notificacion del CRM UDEC Facatativa<br>
</p>

</body>
</html>